﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace the_quadratic_equation
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.Write("Введите a: ");
			double a = Convert.ToDouble(Console.ReadLine());
			Console.Write("Введите x: ");
			double x = Convert.ToDouble(Console.ReadLine());
			Console.Write("Введите b: ");
			double b = Convert.ToDouble(Console.ReadLine());
			Console.Write("Введите c: ");
			double c = Convert.ToDouble(Console.ReadLine());
			double d = Convert.ToDouble(a* Math.Pow(x,2)+b*x+c);
			if (d < 0) Console.WriteLine("Корней нет.");
			else
			{
				double x1 =-(b - Math.Sqrt(d)) / (2*a);
				double x2 =-(b + Math.Sqrt(d)) / 2;
				Convert.ToBoolean(x1);
				Convert.ToBoolean(x2);
				if (x1 == x2) Console.WriteLine("Один корень: x={0}", x1);
				else Console.WriteLine("Два корня: x1={0}; x2={1}", x1, x2);
			}
			Console.WriteLine("Нажмите любую клавишу 	.	.	.");
			Console.ReadKey();
		}
	}
}
